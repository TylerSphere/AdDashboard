export interface AdData {
  id: number;
  headline: string;
  creative: string;
  copy: string;
  reach: number;
  clicks: number;
  isVariation?: boolean;
}

export interface AdMetrics {
  ctr: number;
  winningAd: {
    adNumber: number;
    isV2: boolean;
  };
  probabilities: Array<{
    adNumber: number;
    isV2: boolean;
    probability: number;
  }>;
}

export type AdVariable = 'headline' | 'creative' | 'copy';

export const AD_COUNTS: Record<AdVariable, number> = {
  headline: 15,
  creative: 15,
  copy: 5
} as const;