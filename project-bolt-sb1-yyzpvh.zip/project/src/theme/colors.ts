export const brandColors = {
  primary: {
    start: '#3871c1',
    end: '#c74be4',
  },
  secondary: {
    start: '#24d8cb',
    end: '#3871c1',
  },
} as const;

export const gradients = {
  primary: `linear-gradient(135deg, ${brandColors.primary.start}, ${brandColors.primary.end})`,
  secondary: `linear-gradient(135deg, ${brandColors.secondary.start}, ${brandColors.secondary.end})`,
} as const;