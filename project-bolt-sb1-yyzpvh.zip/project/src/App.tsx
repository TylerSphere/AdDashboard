import { MantineProvider, createTheme } from '@mantine/core';
import { AdDashboard } from './components/AdDashboard';
import { brandColors } from './theme/colors';

const theme = createTheme({
  primaryColor: 'brand',
  colors: {
    brand: [
      '#e9f0f9',
      '#d4e1f4',
      '#a9c3e9',
      '#7ea5de',
      '#538bd3',
      '#3871c1',
      '#2d5a9a',
      '#224474',
      '#162d4d',
      '#0b1727',
    ],
  },
  defaultGradient: {
    from: brandColors.primary.start,
    to: brandColors.primary.end,
    deg: 135,
  },
});

function App() {
  return (
    <MantineProvider theme={theme}>
      <div style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
        <AdDashboard />
      </div>
    </MantineProvider>
  );
}

export default App;