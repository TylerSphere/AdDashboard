import { saveAs } from 'file-saver';
import { AdData, AdVariable } from '../types/AdData';
import { generateCSVContent } from './csvUtils';

export const downloadCSV = (data: string, filename: string): void => {
  const blob = new Blob([data], { type: 'text/csv;charset=utf-8;' });
  saveAs(blob, filename);
};

export const exportAllData = (data: Record<AdVariable, AdData[]>): void => {
  const timestamp = new Date().toISOString().split('T')[0];
  
  Object.entries(data).forEach(([variable, ads]) => {
    const csvData = generateCSVContent(ads, variable as AdVariable);
    const filename = `calibration-method-${variable}-data-${timestamp}.csv`;
    downloadCSV(csvData, filename);
  });
};