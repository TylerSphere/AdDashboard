import { AdData, AdMetrics } from '../../types/AdData';
import { calculateCTR } from './ctrCalculator';
import { findBestPerformingAd } from './performanceCalculator';
import { calculateWinningProbabilities } from './probabilityCalculator';

export const calculateMetrics = (ads: AdData[]): AdMetrics => {
  const ctrs = ads.map(ad => calculateCTR(ad.clicks, ad.reach));
  const avgCTR = ctrs.reduce((sum, ctr) => sum + ctr, 0) / ads.length;
  const winningAd = findBestPerformingAd(ads);
  const probabilities = calculateWinningProbabilities(ads);

  return {
    ctr: avgCTR,
    winningAd,
    probabilities
  };
};