import { AdData } from '../../types/AdData';
import { calculateCTR } from './ctrCalculator';

export const findBestPerformingAd = (ads: AdData[]): {
  adNumber: number;
  isV2: boolean;
} => {
  let bestScore = -1;
  let bestAdIndex = 0;

  ads.forEach((ad, index) => {
    const ctr = calculateCTR(ad.clicks, ad.reach);
    const score = ctr * Math.log(ad.reach + 1);
    
    if (score > bestScore) {
      bestScore = score;
      bestAdIndex = index;
    }
  });

  return {
    adNumber: Math.ceil((bestAdIndex + 1) / 2),
    isV2: ads[bestAdIndex]?.isVariation || false
  };
};