import { AdData } from '../../types/AdData';

export const calculateCTR = (clicks: number, reach: number): number => {
  if (reach === 0) return 0;
  return (clicks / reach) * 100;
};