import { AdData } from '../../types/AdData';
import { calculateCTR } from './ctrCalculator';

export interface AdProbability {
  adNumber: number;
  isV2: boolean;
  probability: number;
}

export const calculateWinningProbabilities = (ads: AdData[]): AdProbability[] => {
  const scores = ads.map(ad => {
    const ctr = calculateCTR(ad.clicks, ad.reach);
    const reachFactor = Math.log(ad.reach + 1);
    return {
      score: ctr * reachFactor,
      confidence: Math.min(1, ad.reach / 1000)
    };
  });

  const maxScore = Math.max(...scores.map(s => s.score));
  
  if (maxScore === 0) {
    return ads.map((ad, index) => ({
      adNumber: Math.ceil((index + 1) / 2),
      isV2: ad.isVariation || false,
      probability: 0
    }));
  }

  return scores.map((score, index) => {
    const relativePerformance = score.score / maxScore;
    const winningProbability = relativePerformance * score.confidence * 100;

    return {
      adNumber: Math.ceil((index + 1) / 2),
      isV2: ads[index]?.isVariation || false,
      probability: Math.min(100, Math.max(0, winningProbability))
    };
  });
};