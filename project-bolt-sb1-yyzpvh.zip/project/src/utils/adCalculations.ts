import { AdData, AdMetrics } from '../types/AdData';

export const calculateCTR = (clicks: number, reach: number): number => {
  if (reach === 0) return 0;
  return (clicks / reach) * 100;
};

export const findBestPerformingAd = (ads: AdData[]): {
  adNumber: number;
  isV2: boolean;
} => {
  let bestScore = -1;
  let bestAdIndex = 0;

  ads.forEach((ad, index) => {
    const ctr = calculateCTR(ad.clicks, ad.reach);
    const score = ctr * Math.log(ad.reach + 1);
    
    if (score > bestScore) {
      bestScore = score;
      bestAdIndex = index;
    }
  });

  return {
    adNumber: Math.ceil((bestAdIndex + 1) / 2),
    isV2: ads[bestAdIndex]?.isVariation || false
  };
};

export const calculateWinningProbabilities = (ads: AdData[]): Array<{
  adNumber: number;
  isV2: boolean;
  probability: number;
}> => {
  // Calculate performance scores based on CTR and reach
  const scores = ads.map(ad => {
    const ctr = calculateCTR(ad.clicks, ad.reach);
    const reachFactor = Math.log(ad.reach + 1);
    return {
      score: ctr * reachFactor,
      confidence: Math.min(1, ad.reach / 1000) // Confidence factor based on reach
    };
  });

  const maxScore = Math.max(...scores.map(s => s.score));
  
  if (maxScore === 0) {
    return ads.map((ad, index) => ({
      adNumber: Math.ceil((index + 1) / 2),
      isV2: ad.isVariation || false,
      probability: 0
    }));
  }

  // Calculate relative probabilities with confidence weighting
  return scores.map((score, index) => {
    const relativePerformance = score.score / maxScore;
    const winningProbability = relativePerformance * score.confidence * 100;

    return {
      adNumber: Math.ceil((index + 1) / 2),
      isV2: ads[index]?.isVariation || false,
      probability: Math.min(100, Math.max(0, winningProbability)) // Ensure between 0-100
    };
  });
};

export const calculateMetrics = (ads: AdData[]): AdMetrics => {
  const ctrs = ads.map(ad => calculateCTR(ad.clicks, ad.reach));
  const avgCTR = ctrs.reduce((sum, ctr) => sum + ctr, 0) / ads.length;
  const winningAd = findBestPerformingAd(ads);
  const probabilities = calculateWinningProbabilities(ads);

  return {
    ctr: avgCTR,
    winningAd,
    probabilities
  };
};