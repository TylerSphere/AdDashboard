import { AdData } from '../types/AdData';

export const createInitialAds = (count: number): AdData[] => {
  const ads: AdData[] = [];
  for (let i = 0; i < count; i++) {
    // Main version
    ads.push({
      id: i * 2 + 1,
      headline: '',
      creative: '',
      copy: '',
      reach: 0,
      clicks: 0,
      isVariation: false
    });
    // V2 version
    ads.push({
      id: i * 2 + 2,
      headline: '',
      creative: '',
      copy: '',
      reach: 0,
      clicks: 0,
      isVariation: true
    });
  }
  return ads;
};