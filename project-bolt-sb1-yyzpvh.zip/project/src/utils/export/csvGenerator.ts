import { AdData, AdVariable } from '../../types/AdData';
import { calculateCTR } from '../adCalculations';
import { formatAdName } from '../formatters';

export const generateCSVContent = (ads: AdData[], variable: AdVariable): string => {
  const headers = [`${variable} Number`, variable, 'Reach', 'Clicks', 'CTR'];
  const rows = [headers.join(',')];

  ads.forEach(ad => {
    const ctr = calculateCTR(ad.clicks, ad.reach);
    const adNumber = Math.ceil(ad.id / 2);
    const adName = formatAdName(adNumber, ad.isVariation || false);
    
    const row = [
      adName,
      `"${ad[variable]}"`,
      ad.reach,
      ad.clicks,
      `${ctr.toFixed(2)}%`
    ];
    
    rows.push(row.join(','));
  });

  return rows.join('\n');
};