import { saveAs } from 'file-saver';

export const downloadCSV = (data: string, filename: string): void => {
  const blob = new Blob([data], { type: 'text/csv;charset=utf-8;' });
  saveAs(blob, filename);
};