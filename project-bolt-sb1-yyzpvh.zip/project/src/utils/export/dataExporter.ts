import { AdData, AdVariable } from '../../types/AdData';
import { generateCSVContent } from './csvGenerator';
import { downloadCSV } from './fileDownloader';

export const exportAllData = (data: Record<AdVariable, AdData[]>): void => {
  const timestamp = new Date().toISOString().split('T')[0];
  
  Object.entries(data).forEach(([variable, ads]) => {
    const csvData = generateCSVContent(ads, variable as AdVariable);
    const filename = `calibration-method-${variable}-data-${timestamp}.csv`;
    downloadCSV(csvData, filename);
  });
};