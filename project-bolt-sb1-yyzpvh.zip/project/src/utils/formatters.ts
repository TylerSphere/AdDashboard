export const formatAdName = (adNumber: number, isV2: boolean): string => {
  return `Ad ${adNumber}${isV2 ? ' V2' : ''}`;
};

export const formatVariableLabel = (variable: string): string => {
  return variable.charAt(0).toUpperCase() + variable.slice(1);
};