import { useState } from 'react';
import { Paper, Title, Tabs, ScrollArea, Button, Group } from '@mantine/core';
import { IconDownload } from '@tabler/icons-react';
import { AdData, AdVariable, AD_COUNTS } from '../types/AdData';
import { calculateMetrics } from '../utils/adCalculations';
import { exportAllData } from '../utils/exportUtils';
import { AdVariableTab } from './AdVariableTab';
import { gradients, brandColors } from '../theme/colors';
import { getTabStyles } from './tabs/TabStyles';
import { createInitialAds } from '../utils/adInitializer';

export function AdDashboard() {
  const [activeTab, setActiveTab] = useState<AdVariable>('headline');
  const [adsByVariable, setAdsByVariable] = useState<Record<AdVariable, AdData[]>>({
    headline: createInitialAds(AD_COUNTS.headline),
    creative: createInitialAds(AD_COUNTS.creative),
    copy: createInitialAds(AD_COUNTS.copy)
  });

  const handleUpdate = (id: number, field: keyof AdData, value: string | number) => {
    setAdsByVariable(prev => ({
      ...prev,
      [activeTab]: prev[activeTab].map(ad =>
        ad.id === id ? { ...ad, [field]: value } : ad
      )
    }));
  };

  const handleTabChange = (value: string | null) => {
    if (value) {
      setActiveTab(value as AdVariable);
    }
  };

  const metrics = calculateMetrics(adsByVariable[activeTab]);

  return (
    <Paper p="xl" radius="md" withBorder>
      <Group justify="space-between" mb="lg">
        <Title
          order={1}
          style={{
            background: gradients.primary,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}
        >
          The Calibration Method Dashboard
        </Title>
        <Button
          leftSection={<IconDownload size={16} />}
          variant="gradient"
          gradient={{ from: brandColors.secondary.start, to: brandColors.secondary.end, deg: 135 }}
          onClick={() => exportAllData(adsByVariable)}
        >
          Export All Data
        </Button>
      </Group>

      <Tabs 
        value={activeTab} 
        onChange={handleTabChange}
        mb="xl"
        styles={getTabStyles(brandColors.secondary.start)}
      >
        <Tabs.List grow>
          <Tabs.Tab value="headline">Headline Testing ({AD_COUNTS.headline} Ads)</Tabs.Tab>
          <Tabs.Tab value="creative">Creative Testing ({AD_COUNTS.creative} Ads)</Tabs.Tab>
          <Tabs.Tab value="copy">Copy Testing ({AD_COUNTS.copy} Ads)</Tabs.Tab>
        </Tabs.List>
      </Tabs>

      <ScrollArea h={600}>
        <AdVariableTab
          ads={adsByVariable[activeTab]}
          onUpdate={handleUpdate}
          metrics={metrics}
          activeVariable={activeTab}
        />
      </ScrollArea>
    </Paper>
  );
}