import { Table, TextInput, NumberInput, Text } from '@mantine/core';
import { AdData, AdVariable } from '../../types/AdData';
import { brandColors, gradients } from '../../theme/colors';

interface AdTableRowProps {
  ad: AdData;
  activeVariable: AdVariable;
  onUpdate: (id: number, field: keyof AdData, value: string | number) => void;
}

export function AdTableRow({ ad, activeVariable, onUpdate }: AdTableRowProps) {
  const ctr = ad.reach === 0 ? 0 : (ad.clicks / ad.reach) * 100;
  const isV2 = ad.isVariation;
  const adNumber = Math.ceil(ad.id / 2);

  return (
    <Table.Tr 
      style={{
        backgroundColor: isV2 ? 'rgba(36, 216, 203, 0.05)' : undefined,
        borderLeft: isV2 ? `4px solid ${brandColors.secondary.start}` : undefined
      }}
    >
      <Table.Td>
        <Text 
          fw={500}
          style={isV2 ? {
            background: gradients.secondary,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          } : undefined}
        >
          {isV2 ? `Ad ${adNumber} V2` : `Ad ${adNumber}`}
        </Text>
      </Table.Td>
      <Table.Td style={{ minWidth: '300px' }}>
        <TextInput
          value={ad[activeVariable]}
          onChange={(e) => onUpdate(ad.id, activeVariable, e.target.value)}
          placeholder={`Enter ${activeVariable}${isV2 ? ' variation' : ''}`}
          styles={{
            input: {
              borderColor: isV2 ? brandColors.secondary.start : undefined,
              '&:focus': {
                borderColor: isV2 ? brandColors.secondary.end : undefined
              }
            }
          }}
        />
      </Table.Td>
      <Table.Td>
        <NumberInput
          value={ad.reach}
          onChange={(value) => onUpdate(ad.id, 'reach', value || 0)}
          min={0}
        />
      </Table.Td>
      <Table.Td>
        <NumberInput
          value={ad.clicks}
          onChange={(value) => onUpdate(ad.id, 'clicks', value || 0)}
          min={0}
        />
      </Table.Td>
      <Table.Td>
        <Text style={{ color: brandColors.secondary.start, fontWeight: 500 }}>
          {ctr.toFixed(2)}%
        </Text>
      </Table.Td>
    </Table.Tr>
  );
}