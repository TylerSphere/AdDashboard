import { MantineTheme } from '@mantine/core';

interface TabStyleProps {
  tab: {
    position: 'relative';
    transition: string;
    borderRadius: string;
    border: string;
    borderBottom: string;
    backgroundColor: string;
    boxShadow: string;
    '&:hover': {
      transform: string;
      backgroundColor: string;
      boxShadow: string;
    };
    '&[data-active]': {
      backgroundColor: string;
      borderColor: string;
      boxShadow: string;
      '&::after': {
        content: string;
        position: 'absolute';
        bottom: string;
        left: string;
        right: string;
        height: string;
        backgroundColor: string;
      };
    };
  };
  tabsList: {
    borderBottom: string;
    gap: string;
  };
}

export const getTabStyles = (borderColor: string): TabStyleProps => ({
  tab: {
    position: 'relative',
    transition: 'all 0.2s ease',
    borderRadius: '4px 4px 0 0',
    border: '1px solid transparent',
    borderBottom: 'none',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    boxShadow: '0 -2px 4px rgba(0,0,0,0.1)',
    '&:hover': {
      transform: 'translateY(-2px)',
      backgroundColor: 'rgba(255, 255, 255, 0.2)',
      boxShadow: '0 -4px 8px rgba(0,0,0,0.15)',
    },
    '&[data-active]': {
      backgroundColor: 'white',
      borderColor,
      boxShadow: '0 -4px 8px rgba(0,0,0,0.15)',
      '&::after': {
        content: '""',
        position: 'absolute',
        bottom: '-2px',
        left: '0',
        right: '0',
        height: '2px',
        backgroundColor: 'white',
      },
    },
  },
  tabsList: {
    borderBottom: `2px solid ${borderColor}`,
    gap: '4px',
  },
});