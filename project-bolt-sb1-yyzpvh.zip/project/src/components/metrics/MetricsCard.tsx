import { Text } from '@mantine/core';
import { gradients } from '../../theme/colors';

interface MetricsCardProps {
  label: string;
  value: string;
  gradient?: 'primary' | 'secondary';
}

export function MetricsCard({ label, value, gradient = 'secondary' }: MetricsCardProps) {
  return (
    <div>
      <Text size="lg" fw={500}>{label}</Text>
      <Text 
        size="xl"
        style={{
          background: gradients[gradient],
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
          fontWeight: 600,
        }}
      >
        {value}
      </Text>
    </div>
  );
}