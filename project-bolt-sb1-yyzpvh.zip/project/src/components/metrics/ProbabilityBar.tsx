import { Group, Text, Box } from '@mantine/core';
import { gradients, brandColors } from '../../theme/colors';

interface ProbabilityBarProps {
  adName: string;
  probability: number;
}

export function ProbabilityBar({ adName, probability }: ProbabilityBarProps) {
  return (
    <div>
      <Group justify="space-between" mb={3}>
        <Text 
          size="sm"
          style={{
            background: gradients.secondary,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            fontWeight: 500,
          }}
        >
          {adName}
        </Text>
        <Text 
          size="sm"
          style={{
            background: gradients.primary,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            fontWeight: 600,
          }}
        >
          {probability.toFixed(0)}%
        </Text>
      </Group>
      <Box
        style={{
          height: '6px',
          width: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.1)',
          borderRadius: '999px',
          overflow: 'hidden',
        }}
      >
        <Box
          style={{
            height: '100%',
            width: `${probability}%`,
            background: `linear-gradient(135deg, ${brandColors.secondary.start}, ${brandColors.secondary.end})`,
            borderRadius: '999px',
            transition: 'width 0.3s ease',
          }}
        />
      </Box>
    </div>
  );
}