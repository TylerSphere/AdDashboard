import { Table } from '@mantine/core';
import { AdData, AdVariable } from '../types/AdData';
import { brandColors } from '../theme/colors';
import { AdTableRow } from './table/AdTableRow';
import { formatVariableLabel } from '../utils/formatters';

interface AdInputTableProps {
  ads: AdData[];
  activeVariable: AdVariable;
  onUpdate: (id: number, field: keyof AdData, value: string | number) => void;
}

export function AdInputTable({ ads, activeVariable, onUpdate }: AdInputTableProps) {
  return (
    <Table striped={false} highlightOnHover>
      <Table.Thead>
        <Table.Tr style={{ background: brandColors.primary.start }}>
          <Table.Th style={{ color: 'white' }}>Ad #</Table.Th>
          <Table.Th style={{ color: 'white' }}>{formatVariableLabel(activeVariable)}</Table.Th>
          <Table.Th style={{ color: 'white' }}>Reach</Table.Th>
          <Table.Th style={{ color: 'white' }}>Clicks</Table.Th>
          <Table.Th style={{ color: 'white' }}>CTR</Table.Th>
        </Table.Tr>
      </Table.Thead>
      <Table.Tbody>
        {ads.map(ad => (
          <AdTableRow
            key={ad.id}
            ad={ad}
            activeVariable={activeVariable}
            onUpdate={onUpdate}
          />
        ))}
      </Table.Tbody>
    </Table>
  );
}