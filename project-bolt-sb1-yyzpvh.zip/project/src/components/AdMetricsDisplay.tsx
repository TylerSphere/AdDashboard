import { Paper, SimpleGrid, Stack } from '@mantine/core';
import { AdMetrics, AdVariable } from '../types/AdData';
import { MetricsCard } from './metrics/MetricsCard';
import { ProbabilityBar } from './metrics/ProbabilityBar';
import { formatAdName, formatVariableLabel } from '../utils/formatters';

interface AdMetricsDisplayProps {
  metrics: AdMetrics;
  activeVariable: AdVariable;
}

export function AdMetricsDisplay({ metrics, activeVariable }: AdMetricsDisplayProps) {
  return (
    <Paper withBorder p="md" mt="xl" radius="md">
      <SimpleGrid cols={3}>
        <MetricsCard
          label="Average CTR"
          value={`${metrics.ctr.toFixed(2)}%`}
        />
        <MetricsCard
          label={`Best Performing ${formatVariableLabel(activeVariable)}`}
          value={formatAdName(metrics.winningAd.adNumber, metrics.winningAd.isV2)}
          gradient="primary"
        />
        <div>
          <MetricsCard
            label="Winning Probability"
            value=""
          />
          <Stack gap="xs">
            {metrics.probabilities
              .sort((a, b) => b.probability - a.probability)
              .slice(0, 3)
              .map(({ adNumber, isV2, probability }) => (
                <ProbabilityBar
                  key={`${adNumber}-${isV2}`}
                  adName={formatAdName(adNumber, isV2)}
                  probability={probability}
                />
              ))}
          </Stack>
        </div>
      </SimpleGrid>
    </Paper>
  );
}