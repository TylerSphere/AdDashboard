import { AdData, AdMetrics, AdVariable } from '../types/AdData';
import { AdInputTable } from './AdInputTable';
import { AdMetricsDisplay } from './AdMetricsDisplay';

interface AdVariableTabProps {
  ads: AdData[];
  metrics: AdMetrics;
  activeVariable: AdVariable;
  onUpdate: (id: number, field: keyof AdData, value: string | number) => void;
}

export function AdVariableTab({ ads, metrics, activeVariable, onUpdate }: AdVariableTabProps) {
  return (
    <>
      <AdInputTable
        ads={ads}
        onUpdate={onUpdate}
        activeVariable={activeVariable}
      />
      <AdMetricsDisplay metrics={metrics} activeVariable={activeVariable} />
    </>
  );
}